package Calculadora.CalculadoraTeste;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.lang.math.NumberUtils;;

public class App {
	public static void main(String[] args) {

		String operacao = lerArquivo("D:\\calculadora.txt");
		System.out.println("Lido: " + operacao);

		if (validaAnaliseLexica(operacao)) {
			AnaliseSintatica analiseSintatica = new AnaliseSintatica(operacao);
			if(analiseSintatica.validaAnaliseSintatica()) {
				System.out.println("Expressão sem erro sintático.");
			}
			else {
				System.out.println("Expressão COM erro sintático.");
			}
		}

	}

	public static String lerArquivo(String caminho) {
		try {
			InputStream is = new FileInputStream(caminho);
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();
			while (line != null) {
				sb.append(line).append("\n");
				line = buf.readLine();
			}
			buf.close();
			return sb.toString();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean validaAnaliseLexica(String operacao) {
		boolean valido = true;
		for (int i = 0; i < operacao.length(); i++) {
			char atual = operacao.charAt(i);
			String sAtual = atual + "";
			if (atual == ' ' || atual == '(' || atual == ')' || atual == '\n' || ehOperacao(atual)
					|| NumberUtils.isNumber(sAtual)) {
				continue;
			}
			System.out.println("Erro léxico encontrado: símbolo " + atual + " não conhecido ");
			valido = false;
		}
		if (valido) {
			System.out.println("Expressão sem erro léxico.");
		}
		return valido;
	}

	public static boolean ehOperacao(char c) {
		if (c == '+' || c == '-' || c == '/' || c == '*') {
			return true;
		}
		return false;
	}
}
