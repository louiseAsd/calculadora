package Calculadora.CalculadoraTeste;

import org.apache.commons.lang.math.NumberUtils;

public class AnaliseSintatica {
	
	private Estado estadoAtual;
	private int parentesesAbertos = 0;
	private String operacao;
	
	public AnaliseSintatica(String operacao) {
		this.operacao = operacao;
	}
	
	public boolean validaAnaliseSintatica() {
		int i = 0;
		char primeiro;
		do {
			primeiro = operacao.charAt(i);
			i++;
		} while (primeiro == ' ');
		estadoAtual = validaPrimeiroCaracter(primeiro);
		if (estadoAtual == null) {
			return false;
		}
		if(!validaCaracteresMeio(i)) {
			return false;
		}
		if (estadoAtual == Estado.OPERACAO || estadoAtual == Estado.PARENTESES_ABRE || parentesesAbertos > 0) {
			return false;
		}
		return true;
	}
	
	private Estado validaPrimeiroCaracter(char primeiro) {
		if (primeiro == '(') {
			parentesesAbertos++;
			return Estado.PARENTESES_ABRE;
		}
		String sPrimeiro = primeiro + "";
		if (NumberUtils.isNumber(sPrimeiro)) {
			return Estado.NUMERO;
		}
		return null;
	}
	
	private boolean validaCaracteresMeio(int i) {
		for (int j = i; j < operacao.length(); j++) {
			char atual = operacao.charAt(j);
			if (atual == ' ' || atual == '\n') {
				continue;
			}
			if (validaParentesesFechado(atual)) {
				estadoAtual = Estado.PARENTESES_FECHA;
				parentesesAbertos--;
				continue;
			}
			if(validaParentesesAberto(atual)) {
				estadoAtual = Estado.PARENTESES_ABRE;
				parentesesAbertos++;
				continue;
			}
			if(validaOperacao(atual)) {
				estadoAtual = Estado.OPERACAO;
				continue;
			}
			if (validaNumero(atual)) {
				estadoAtual = Estado.NUMERO;
				continue;
			}
			return false;
		}
		return true;
	}
	
	private boolean validaParentesesFechado(char c) {
		if (c != ')' || estadoAtual == Estado.OPERACAO || estadoAtual == Estado.PARENTESES_ABRE
				|| parentesesAbertos == 0) {
			return false;
		}
		return true;
	}
	
	private boolean validaParentesesAberto(char c) {
		if (c != '(' || estadoAtual == Estado.PARENTESES_FECHA || estadoAtual == Estado.NUMERO) {
			return false;
		}
		return true;
	}
	
	private boolean validaOperacao(char c) {
		if (!App.ehOperacao(c) || estadoAtual == Estado.OPERACAO || estadoAtual == Estado.PARENTESES_ABRE) {
			return false;
		}
		return true;
	}
	
	private boolean validaNumero(char c) {
		String sAtual = c + "";
		if (!NumberUtils.isNumber(sAtual) || estadoAtual == Estado.PARENTESES_FECHA) {
			return false;
		}
		return true;
	}
	
}
