package Calculadora.CalculadoraTeste;

public enum Estado {
	
	NUMERO, PARENTESES_ABRE, PARENTESES_FECHA, OPERACAO;

}
